import requests
import json

def updateErrors(base_url, data):
    url = base_url+"/"
    headers = {}
    headers['Cache-Control'] = 'no-cache'
    headers['Content-Type'] = "application/json"

    for obj in data:
        id = obj['_id']
        update_url = url+obj['_index']+'/doc/'+id+'/_update'
        update = {"doc":{"err_type": "Data_Issue"}}
        print (json.dumps(update))
        response = requests.request("POST",update_url, headers=headers, data=json.dumps(update))
        if(response.status_code != requests.codes.ok):
            print("Problem encountered while updating document")

def printData(data):
    for obj in data:
        print (obj)

def fetchErrorsWithWrongErrorType(base_url):
    # Querying new errors from elastic using scroll api
    # matchq = [{"match" : {"tags": {"query": "exceptionFound","type": "phrase"}}}]
    rangeq = [{"range": {"@timestamp": {"gte": "now-120d","lte": "now"}}}]
    # mustNotq = {"exists" : { "field" : "err_type" }}
    match2 = [{"match": {"err_type": "Data Issue"}}]
    # body = {"query": {"bool": {"filter": rangeq, "must": match2}}}

    url = base_url+"/mtf*/_search"
    headers = {}
    body = {"_source": ["err_ty*"], "query": {"bool": {"filter": {"range": {"@timestamp": {"gte": "now-90d","lte": "now"}}}, "must": {"match": {"err_type": "Data Issue"}}}}}
    headers['Cache-Control'] = 'no-cache'
    headers['Content-Type'] = "application/json"
    response = requests.request("GET", url, headers=headers, data=json.dumps(body))
    data = json.loads(response.text)
    hits = data['hits']['total']
    print("Total results -", hits)

    #updateErrors(data)
    return data

if __name__ == "__main__":
    base_url = "http://datlelasticclient02.cme.in.here.com:9200"
    data = fetchErrorsWithWrongErrorType(base_url)
    # data = [{"_index": "mtf-szam18124wsz000_1774711_ext.out", "_id": "AWU4m_W1t88fty3N35BC"}]
    hits = data['hits']['hits']
    print("updating -", len(hits))
    # printData(hits)
    updateErrors(base_url, hits)