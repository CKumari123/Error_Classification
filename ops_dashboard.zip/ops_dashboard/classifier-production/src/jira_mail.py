import json
import smtplib
from email.mime.text import MIMEText

def send_jira_mail(msg_url, receiver, subject):

    with open('user.json') as f:
        account_details = json.load(f)
    sender = account_details.get('outlook_email')
    password = account_details.get('outlook_password')

    msg = MIMEText(msg_url)
    msg['From'] = sender
    msg['To'] = receiver
    msg['Subject'] = subject

    mailserver = smtplib.SMTP('smtp.office365.com',587)
    mailserver.ehlo()
    mailserver.starttls()
    mailserver.ehlo()
    mailserver.login(sender, password)
    mailserver.sendmail(sender, receiver, msg.as_string())

    mailserver.quit()
