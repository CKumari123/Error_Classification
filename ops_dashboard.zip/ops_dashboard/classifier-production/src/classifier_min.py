import pandas as pd
import numpy as np
from io import StringIO
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.externals import joblib
from nltk import WordNetLemmatizer
from sklearn.metrics import classification_report,accuracy_score


elle = WordNetLemmatizer()
class elleTfidfVectorizer(TfidfVectorizer):
    def build_analyzer(self):
        analyzer = super(elleTfidfVectorizer, self).build_analyzer()
        return lambda doc: ([elle.lemmatize(w) for w in analyzer(doc)])


if __name__ == "__main__":

    df = pd.read_csv('final.csv')
    df['type_id'] = df['err_type'].factorize()[0]
    type_id_df = df[['err_type', 'type_id']].drop_duplicates().sort_values('type_id')
    type_to_id = dict(type_id_df.values)
    id_to_type = dict(type_id_df[['type_id', 'err_type']].values)

    X_train, X_test, y_train, y_test = train_test_split(df['clean'], df['err_type'], random_state = 4)
    tfidf = elleTfidfVectorizer(sublinear_tf=True, min_df=2, max_df=0.5, norm='l2', encoding='latin-1', ngram_range=(1, 3), stop_words='english')
    X_train_tfidf = tfidf.fit_transform(X_train)


    # applying logistic regression algorithm
    clf1 = LogisticRegression(C=30.0, class_weight='balanced', solver='newton-cg', multi_class='multinomial', n_jobs=1, random_state=40)
    clf1.fit(X_train_tfidf, y_train)
    pred1 = clf1.predict(tfidf.transform(X_test))
    print("accuracy score:"+str(accuracy_score(y_test, pred1)))
    print(classification_report(y_test, pred1))

    #applying decision tree classification algorithm 

    model = 'saved_model'
    vocab = 'saved_vocab'
    joblib.dump(clf1,model)
    joblib.dump(tfidf, vocab)


