import requests
import json
import sys
import jira_creator
import pandas as pd
# from time import sleep, time
from functools import reduce
from cleaner import cleaner
from sklearn.externals import joblib
from classifier_min import elleTfidfVectorizer

def unique_error(series):
    return reduce(lambda x, y: x + '\n' + y, series)


def find_new_errors(base_url):
    # Querying new errors from elastic using scroll api
    matchq = [{"match" : {"tags": {"query": "exceptionFound","type": "phrase"}}}]
    rangeq = [{"range": {"@timestamp": {"gte": "now-7d","lte": "now"}}}]
    mustNotq = {"exists" : { "field" : "err_type" }}
    body = {"query": {"bool": {"must": matchq,"filter": rangeq, "must_not": mustNotq }}}

    url = base_url+"/mtf-exceptions/_count"
    headers = {}
    headers['Cache-Control'] = 'no-cache'
    headers['Content-Type'] = "application/json"
    response = requests.request("GET", url, headers=headers, data=json.dumps(body))
    data = json.loads(response.text)
    total = data['count']
    print("Total Severe errors detected in past", total)
    if total == 0:
        return None, None

    body['size'] = 1000
    url = base_url+"/mtf-exceptions/_search?scroll=2m"
    response = requests.request("POST", url, headers=headers, data=json.dumps(body))
    data = json.loads(response.text)
    scroll_id = data['_scroll_id']
    hits = json.loads(response.text)['hits']['hits']
    errors = []
    meta = []
    source_dict = {}
    for obj in hits:
        errors.append([obj['_source']['message'],obj['_source']['productname']])
        meta.append((obj['_index'], obj['_id']))
        source_dict[obj['_index']] = obj['_source']

    url = base_url+"/_search/scroll"
    scroll_body = {}
    scroll_body["scroll"] = "2m"
    for i in range(0,total//body['size']):
        scroll_body["scroll_id"] = scroll_id 
        response = requests.request("POST", url, headers=headers, data=json.dumps(scroll_body))
        data = json.loads(response.text)
        scroll_id = data['_scroll_id']
        hits = data['hits']['hits']
        for obj in hits:
            errors.append([obj['_source']['message'],obj['_source']['productname']])
            meta.append((obj['_index'], obj['_id']))
            source_dict[obj['_index']] = obj['_source']

    # Cleaning data for classification
    df = cleaner(pd.DataFrame(errors, columns=['message','source']))
    df = df.drop_duplicates(subset=['clean','source'])
    error_details = {}
    for idx,data in df.iterrows():
        df.loc[idx,'index'] = meta[idx][0]
        df.loc[idx,'id'] = meta[idx][1]
        error_details[meta[idx][0]] = source_dict[meta[idx][0]]

    # Deleting redundant variables
    del source_dict, meta, errors
    df = df.reset_index(drop=True)
    return df, error_details

# Load the model and vocab and classify
def classify_error(df):

    clf = joblib.load('saved_model')
    tfidf = joblib.load('saved_vocab')
    df['err_type'] = clf.predict(tfidf.transform(df['clean']))
    df = df.groupby(['index','source','err_type'], as_index=False).agg(unique_error)
    df = df.drop(columns = ['source','clean'])
    # df.to_csv('check.csv', index=False)
    return df

def generate_notifs(df, error_details, base_url):

    error_type_dict = {
        'data': 'Data_Issue',
        'env': 'Environment_Issue',
        'app': 'Software_Issue'
    }
    # Writing back error type to elastic doc
    # send a POST to elastic/index/doc/id/_update
    url = base_url+"/"
    print("Job Completed!!")
    headers = {}
    headers['Cache-Control'] = 'no-cache'
    headers['Content-Type'] = "application/json"
    for idx, data in df.iterrows():
        # issue_method = getattr(jira_creator, data['err_type']+'_issue')
        issue_method = getattr(jira_creator, 'app_issue')
        result = issue_method(error_details[data['index']], data['message'], error_type_dict.get(data['err_type'],"New type")) # It returns the key of the created issue
        print(result, data['err_type'])

        doc_ids = data['id'].split('\n')
        for d_id in doc_ids:
            print("DocumentID: " + d_id + ", error_type: " + data['err_type'])
            update_url = url+data['index']+'/doc/'+d_id+'/_update'
            update = {"doc":{"err_type":error_type_dict.get(data['err_type'],"New type"), "jiraId": result}}
            response = requests.request("POST",update_url, headers=headers, data=json.dumps(update))
            if(response.status_code != requests.codes.ok):
                print("Problem encountered while updating document")
                sys.exit()


if __name__ == "__main__":

    print('\nStart exception processing...')
    base_url = "http://elastic-client-atl.cme.in.here.com"
    df, error_details = find_new_errors(base_url)
    if df is not None:
        df = classify_error(df)
        generate_notifs(df, error_details, base_url)
    print('\nException processing completed.')
    # timer = 60*20 #20 minutes into seconds
    # while True:
    #     t_start = time()

        # t_end = time()
        # run_time = (t_end-t_start)%timer
        # sleep(timer - run_time)