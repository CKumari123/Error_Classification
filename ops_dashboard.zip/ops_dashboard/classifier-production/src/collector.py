import requests
import json
import csv
import re
import pandas as pd

url = "http://localhost:9200/_count"
querystring = '''{
    "query": {
        "match" : {
            "logLevel" : "SEVERE"
        }
    }
}'''
headers = {'Cache-Control': 'no-cache','Content-Type': "application/json"}
response = requests.request("GET", url, headers=headers, data=querystring)
data=json.loads(response.text)
total=data['count']
size = 1000

url = "http://localhost:9200/_search?scroll=1m"
querystring ='''{
    "size":1000,
    "query": {
        "match" : {
            "logLevel" : "SEVERE"
        }
    }
}'''
headers = {'Cache-Control': 'no-cache','Content-Type': "application/json"}
response = requests.request("POST", url, headers=headers, data=querystring)
data = json.loads(response.text)
scroll_id = data['_scroll_id']
hits = json.loads(response.text)['hits']['hits']

headers=['id','message']
with open('train.csv', 'w',newline='',encoding="utf-8") as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(headers)
    for obj in hits:
        row=[obj['_id'],obj['_source']['message']]
        writer.writerow(row)

    url = "http://localhost:9200/_search/scroll"

    for i in range(0,total//size):
        querystring = '''{{"scroll_id":"{}", "scroll":"2m"}}'''.format(scroll_id)
        headers = {'Cache-Control': 'no-cache','Content-Type': "application/json"}
        response = requests.request("POST", url, headers=headers, data=querystring)
        print(i)
        data = json.loads(response.text)
        scroll_id = data['_scroll_id']
        hits = data['hits']['hits']
        for obj in hits:
            src = obj['_source']
            row=[obj['_id'],src['message']]
            writer.writerow(row)
            del src,row
        del hits

