import requests
import json
import csv

def fetchErrorsWithMissingContinent(base_url, continents, regions):
	url = base_url
	get_url = base_url + "mtf-product-gaggb/_search"
	headers = {}
	headers['Cache-Control'] = "no-cache"
	headers['Content-Type'] = "application/json"
	body = {"_source": ["productname"],"size": "8000", "query": {"bool":{"must":{"range":{"@timestamp":{"gte" : "2019-02-27", "lt" : "2019-03-14"}}},"must_not":{"exists":{"field":"continent"}}}}}
	response = requests.request("GET", get_url, headers=headers, data=json.dumps(body))
	data = json.loads(response.text)
	hits = data['hits']['total']
	print("Total results -", hits)
	
	source = data['hits']['hits']
	for obj in source:
		productname = obj['_source']['productname']
		id = obj['_id']
		regionCode = productname[:2].upper()
		dvn = productname[4:9].upper()
		
		indx = regions.index(regionCode)
		continent = continents[indx]
		print(productname + " - " + id + " - " + dvn + " - " + regionCode + " - " + continent)
		updateStatsEvent(base_url, id, dvn, regionCode, continent)
	return data

def updateStatsEvent(base_url, id, dvn, regionCode, continent):
	url = base_url
	update_url = url + "mtf-product-gaggb/doc/" + id + "/_update"
	headers = {}
	headers['Cache-Control'] = "no-cache"
	headers['Content-Type'] = "application/json"
	update = {"doc":{"dvn": dvn, "regionCode" : regionCode, "continent": continent}}
	response = requests.request("POST", update_url, headers=headers, data=json.dumps(update))
	print("updating _Id - " + id + " - " + json.dumps(update))
	if(response.status_code != requests.codes.ok):
		print("Problem encountered while updating document - " + id)

def readContinents():
	with open('continent-region.csv') as csvfile:
		readCSV = csv.reader(csvfile, delimiter=',')
		continents = []
		regions = []
		for row in readCSV:
			continent = row[0]
			region = row[1]
			continents.append(continent)
			regions.append(region)
	return continents, regions

if __name__ == "__main__":
	base_url = "http://elastic-client-atl.cme.in.here.com/"
	
	continents, regions = readContinents()
	
	data = fetchErrorsWithMissingContinent(base_url, continents, regions)
	hits = data['hits']['hits']
	print("updating -", len(hits))
	# printData(hits)
