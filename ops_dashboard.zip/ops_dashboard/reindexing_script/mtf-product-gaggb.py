import requests
import json
import logging


filename = []
tag = "reindex"

def getProductNames(base_url):
    get_url = base_url + "mtf-ops/_search"
    headers = {}
    headers['Cache-Control'] = "no-cache"
    headers['Content-Type'] = "application/json"
    body = {"_source": ["productname","tags"],"size": "8000", "query": { 
    "bool": {
      "must_not":{ "match": { "tags.keyword": tag } },
      "must": [
        { "wildcard": { "productCode.keyword": "*GAGGB*"}},
        { "match": { "formatExitCode": "0"    }},
        {"range": {"@timestamp": {"gte": "now-1d"}}}     
      ]
    }       
  }
}
    response = requests.request("GET", get_url, headers=headers, data=json.dumps(body))
    data = json.loads(response.text)
    hits = data['hits']['total']
    logger.debug("Total results for ops '%s' ", hits)
    source = data['hits']['hits']
    for obj in source:
        productName = obj['_source']['productname']
        id_ops = obj['_id'] 
        tags_ops = obj['_source']['tags']
        filename.append(productName)
        sourcelogs = getDocumentsIds(base_url,productName)
        logger.debug("Total documents in Logs is '%s' ", len(sourcelogs))
        logger.debug("Reindexing Started for document '%s' ", productName)
        statuscode = getDocuments(base_url,productName)
        logger.debug("Reindexing Completed for document '%s' ", productName)
        if statuscode == 200:  
            tags_ops.append(tag)
            updateTagOps(base_url,id_ops,tags_ops)
            for id_log in sourcelogs:
                tags_logs = id_log['_source']['tags']
                tags_logs.append(tag)
                updateTagLogs(base_url,id_log['_id'],tags_logs)       
    return filename

def getDocumentsIds(base_url,productName):
    get_url = base_url + "mtf-logs/_search"
    headers = {}
    headers['Cache-Control'] = "no-cache"
    headers['Content-Type'] = "application/json"
    body = {"_source": ["productname","tags"],"size": "8000","query": { 
    "bool": {
        "must_not":{ "match": { "tags.keyword": tag }},      
        "must": [
                    { "match": { "productname.keyword": productName}},
                    { "match": { "formatId.keyword": "GAGGB"}}        
                ]
            }
        }
}
    response = requests.request("GET", get_url, headers=headers, data=json.dumps(body))
    data = json.loads(response.text)
    sourcelogs = data['hits']['hits']
    return sourcelogs
       
def getDocuments(base_url, productName):
    get_url = base_url + "_reindex"
    headers = {}
    headers['Cache-Control'] = "no-cache"
    headers['Content-Type'] = "application/json"
    body = {"size": "8000","source": {"index": "mtf-logs", "query": { 
    "bool": {
        "must_not":{ "match": { "tags.keyword": tag }},      
        "must": [
                    { "match": { "productname.keyword": productName}},
                    { "match": { "formatId.keyword": "GAGGB"}}        
                ]
            }
        }
    },
    "dest":{"index": "mtf-product-gaggb","version_type": "internal"}
}
    return requests.request("POST", get_url, headers=headers, data=json.dumps(body)).status_code
           
def updateTagOps(base_url, id_ops, tags):
    url = base_url
    update_url = url + "mtf-ops/doc/" + id_ops + "/_update"
    headers = {}
    headers['Cache-Control'] = "no-cache"
    headers['Content-Type'] = "application/json"
    update = {"doc":{"tags": tags}}
    response = requests.request("POST", update_url, headers=headers, data=json.dumps(update))
    logger.debug("updating _Id - '%s' - '%s' ",id_ops ,json.dumps(update))
    if(response.status_code != requests.codes.ok):
        logger.debug("Problem encountered while updating document - '%s' " ,id_ops)
        
def updateTagLogs(base_url, id_log, tags):
    url = base_url
    update_url = url + "mtf-logs/doc/" + id_log + "/_update"
    headers = {}   
    headers['Cache-Control'] = "no-cache"
    headers['Content-Type'] = "application/json"
    update = {"doc":{"tags": tags}}
    response = requests.request("POST", update_url, headers=headers, data=json.dumps(update))
    logger.debug("updating _Id - '%s' - '%s' " ,id_log ,json.dumps(update))
    if(response.status_code != requests.codes.ok):
        logger.debug("Problem encountered while updating document - '%s' " + id_log)
          
if __name__ == "__main__":
    
    logging.basicConfig(format='%(asctime)s %(message)s')
    logger=logging.getLogger()
    logger.setLevel(logging.DEBUG)
    base_url = "http://elastic-client-atl.cme.in.here.com/"
    productNames = getProductNames(base_url)
    logger.debug("Total ProductNames in ops is -- '%s'", len(productNames))
    