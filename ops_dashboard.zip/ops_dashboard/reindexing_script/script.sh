#!/bin/sh

# code goes here.
echo "Hi run every 2 min"
# chmod +x /home/mtf-product-gaggb.py
chmod 777 -R /home
python3 /home/mtf-product-gaggb.py