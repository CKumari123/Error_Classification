#! /bin/bash
declare sleepTime
declare -i batchSize
declare -i indexCount

sleepTime=5s
batchSize=2
indexCount=0

cat mtfstats-index-names-remaining.txt | while read -r indexname; do
    echo reindexing - $indexname
    status_code=$(curl --write-out %{http_code} --silent --output /dev/null -H 'Content-Type:application/json' -X POST "elastic-client-atl.cme.in.here.com/_reindex?slices=10" -d'{
    "source": {
      "index": "'$indexname'",
      "query": {
      	"match": {
        	"formatId": "GAGGB"
      	}
    	  }
    },
    "dest": {
      "index": "mtf-product-gaggb",
      "version_type": "internal"
    },
    "script": {
    		"source": "ctx._id = null",
    		"lang": "painless"
  	}
  }')
  echo status_code: $status_code
  if [[ "$status_code" = "200" ]] ; then 
  	echo successful - $indexname
  	echo $indexname >> successful.txt
  else
  	echo failed - $indexname
  	echo $indexname >> failed.txt
  fi
  
  indexCount=indexCount+1
  if [[ "$indexCount" -eq "$batchSize" ]] ; then 
  	indexCount=0
  	echo sleeping for $sleepTime
  	sleep $sleepTime
  fi
  
done