#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue May 14 18:29:38 2019

@author: ckumari
"""

import requests
import json
import sys
import pandas as pd
from functools import reduce
from resolution_cleaner import cleaner
from sklearn.externals import joblib
from resolutionClassifier_model import elleTfidfVectorizer
import warnings
warnings.filterwarnings("ignore")

def unique_error(series):
    return reduce(lambda x, y: x + '\n' + y, series)


def find_new_errors(base_url):

# Querying new errors from elastic using scroll api
    rangeq = [{"range": {"@timestamp":
            {
            "gte": "now-24h",
            "lte" : "now"
            }}}]
    body = {
    "query": { 
        "bool": { 
        "filter": rangeq
        }
    }
    }
   
    url = base_url+"/mtf-exceptions/_count"
    headers = {}
    headers['Cache-Control'] = 'no-cache'
    headers['Content-Type'] = "application/json"
    response = requests.request("GET", url, headers=headers, data=json.dumps(body))
    data = json.loads(response.text)
    total = data['count']
    print("Total errors for resolution since last hour", total)
    if total == 0:
        return None, None
    
    body['size'] = 10000
    url = base_url+"/mtf-exceptions/_search?scroll=2m"
    response = requests.request("POST", url, headers=headers, data=json.dumps(body))
    data = json.loads(response.text)
    scroll_id = data['_scroll_id']
    hits = json.loads(response.text)['hits']['hits']
    errors = []
    meta = []
    source_dict = {}
    for obj in hits:
        errors.append([obj['_source']['message'],obj['_source']['productname']])
        meta.append((obj['_index'], obj['_id']))
        source_dict[obj['_index']] = obj['_source']
        
    url = base_url+"/_search/scroll"
    scroll_body = {}
    scroll_body["scroll"] = "2m"
    for i in range(0,total//body['size']):
        scroll_body["scroll_id"] = scroll_id
        response = requests.request("POST", url, headers=headers, data=json.dumps(scroll_body))
        data = json.loads(response.text)
        scroll_id = data['_scroll_id']
        hits = data['hits']['hits']
        for obj in hits:
            errors.append([obj['_source']['message'],obj['_source']['productname']])
            meta.append((obj['_index'], obj['_id']))
            source_dict[obj['_index']] = obj['_source']    
            
 # Cleaning data for classification
    df = cleaner(pd.DataFrame(errors, columns=['message','source']))
    error_details = {}
    for idx,data in df.iterrows():
        df.loc[idx,'index'] = meta[idx][0]
        df.loc[idx,'id'] = meta[idx][1]
        error_details[meta[idx][0]] = source_dict[meta[idx][0]]

# Deleting redundant variables
    del source_dict, meta, errors
    df = df.reset_index(drop=True)
    return df, error_details

# Load the model and vocab and classify
def classify_error(df):

    clf = joblib.load('saved_model_resolution')
    tfidf = joblib.load('saved_vocab_resolution')
    df['resolution'] = clf.predict(tfidf.transform(df['clean']))
    df = df.drop(columns = ['source','clean'])
    return df          

def generate_notifs(df, error_details, base_url):

    url = base_url+"/"
    headers = {}
    headers['Cache-Control'] = 'no-cache'
    headers['Content-Type'] = "application/json"
    
    for idx, data in df.iterrows():
        doc_ids = data['id'].split('\n')
        for d_id in doc_ids:
            update_url = url+data['index']+'/doc/'+d_id+'/_update'
            update = {"doc":{"resolution":data['resolution']}}
            response = requests.request("POST",update_url, headers=headers, data=json.dumps(update))
            if(response.status_code != requests.codes.ok):
                print("Problem encountered while updating document")
                sys.exit()
    
        
if __name__ == "__main__":
    base_url = "http://elastic-client-atl.cme.in.here.com"
    print('\nStarting')
    df, error_details = find_new_errors(base_url)
    if df is not None:
        df = classify_error(df)
        generate_notifs(df, error_details, base_url)
        
        