#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue May 14 19:10:27 2019

@author: ckumari
"""
import pandas as pd
import re

def cleaner(df):
    noise = "SEVERE:   ******* SEVERE(s) & possibly other problems detected! *******"
    #df = df.drop_duplicates(subset=['message'])
    df = df.apply(lambda x: x.str.strip())
    df = df[df.message != noise]
    df['clean'] = df['message'].str.replace(r"[\.\_]+"," ")
    df['clean'] = df['clean'].str.replace(r"\\\r\n", "")
    df['clean'] = df['clean'].str.replace(r"[^A-Za-z\ \n]+", "")
    df['clean'] = df['clean'].str.lower()
    df['clean'] = df['clean'].apply(lambda x: re.sub(r"[\ \n]+"," ",x))
    df['clean'] = df['clean'].apply(lambda x: re.sub(r"\b[\w]\b","",x))
    return df


if __name__ == "__main__":
    df = cleaner(pd.read_csv('mlcategories.csv', encoding = "ISO-8859-1"))
    #df = df.drop_duplicates(subset=['clean'])
    print('cleaning')
    df.to_csv('resolution_testdata.csv', columns=['message','clean','resolution'], index=False)