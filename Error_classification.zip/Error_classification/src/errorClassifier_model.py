#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue May 14 19:13:02 2019

@author: ckumari
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.externals import joblib
from nltk import WordNetLemmatizer
from sklearn.metrics import classification_report,accuracy_score
import warnings
warnings.filterwarnings("ignore")

elle = WordNetLemmatizer()
class elleTfidfVectorizer(TfidfVectorizer):
    def build_analyzer(self):
        analyzer = super(elleTfidfVectorizer, self).build_analyzer()
        return lambda doc: ([elle.lemmatize(w) for w in analyzer(doc)])


if __name__ == "__main__":

    df = pd.read_csv('errorTestData.csv')
    df['type_id'] = df['err_type'].factorize()[0]
    type_id_df = df[['err_type', 'type_id']].drop_duplicates().sort_values('type_id')
    type_to_id = dict(type_id_df.values)
    id_to_type = dict(type_id_df[['type_id', 'err_type']].values)

    X_train, X_test, y_train, y_test = train_test_split(df['clean'], df['err_type'], random_state = 4)
    tfidf = elleTfidfVectorizer(sublinear_tf=True, min_df=2, max_df=0.5, norm='l2', encoding='latin-1', ngram_range=(1, 3), stop_words='english')
    X_train_tfidf = tfidf.fit_transform(X_train)


    # applying logistic regression algorithm
    clf1 = LogisticRegression(C=30.0, class_weight='balanced', solver='newton-cg', multi_class='multinomial', n_jobs=1, random_state=40)
    clf1.fit(X_train_tfidf, y_train)
    pred1 = clf1.predict(tfidf.transform(X_test))
    print("accuracy score of Logistic Regression classificationalgorithm : "+str(accuracy_score(y_test, pred1)))
    print(classification_report(y_test, pred1))
    
    #apply Naive Bayes classification algorithm
    clf2 = MultinomialNB()
    clf2.fit(X_train_tfidf, y_train)
    pred2 = clf2.predict(tfidf.transform(X_test))
    print("accuracy score of Naive Bayes Classification algorithm :"+str(accuracy_score(y_test, pred2)))
    print(classification_report(y_test, pred2))
    
    #apply decision tree classification algorithm
    clf3=DecisionTreeClassifier()
    clf3.fit(X_train_tfidf, y_train)
    pred3 = clf3.predict(tfidf.transform(X_test))
    print("accuracy score of decision tree classification algorithm :"+str(accuracy_score(y_test, pred3)))
    print(classification_report(y_test, pred3))
    
    #apply support vector machine (SVM) classification algorithm
    clf4=SVC(gamma='scale')
    clf4.fit(X_train_tfidf, y_train)
    pred4 = clf4.predict(tfidf.transform(X_test))
    print("accuracy score of Support Vector Machine (SVM )classification algorithm :"+str(accuracy_score(y_test, pred4)))
    print(classification_report(y_test, pred4))
    
    #apply Random Forest Classification algorithm 
    clf5=RandomForestClassifier()
    clf5.fit(X_train_tfidf, y_train)
    pred5 = clf5.predict(tfidf.transform(X_test))
    print("accuracy score of Random Forest classification algorithm :"+str(accuracy_score(y_test, pred5)))
    print(classification_report(y_test, pred5))
    
    model = 'saved_model_error_type'
    vocab = 'saved_vocab_error_type'
    joblib.dump(clf1,model)
    joblib.dump(tfidf, vocab)
