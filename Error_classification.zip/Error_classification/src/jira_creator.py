import requests
import json
import base64
from jira_mail import send_jira_mail

def convertNone(str):
    if str is None:
        return 'Unknown'
    return str

def find_similar_jira(headers, board, jql):
    api_url = board+"rest/api/2/search/"
    query = {}
    query['jql'] = jql
    query['maxResults'] = 2
    query['fields'] = ['key']

    issues_found = ''
    response = requests.request('POST', api_url, headers=headers, data = json.dumps(query))
    data = json.loads(response.text)
    if(response.status_code == requests.codes.ok):
        issues_found = data['issues']
        print ("issues found")
        print (len(issues_found))
    similar_jiras = ''
    for i in issues_found:
        similar_jiras += board+'browse/'+i['key']+'\n'
        # print ("similar jiras - " + similar_jiras)
    return similar_jiras

def data_issue(body, message):
    board = "https://mapopsjira.in.here.com/"
    api = "rest/api/2/issue"
    name ="OPSDBE_COREMAP"
    summary = convertNone(body['productFormat']) + ' failure for ' + convertNone(body['workspaceName'])
    details = []
    details.append("Region: " + convertNone(body['regionCode']))
    details.append("Map Core Version: " + convertNone(body['mapcoreVersion']))
    details.append("MTF version: " + convertNone(body['mtfVersion']))
    details.append("Failure Message:\n" + message)
    description = '\n'.join(details)

    issue_dict = {
        'fields':{
            'project': {'key': name},
            'issuetype': {'id': '12'},
            'priority': {'id':'2'},
            'summary': summary,
            'description': description,
            'customfield_12601': {'id':'12905'},
            'customfield_14708': '5',
            'customfield_14713': {'id':'14909'}
        }
    }
    jql_text = message.split('\n', 1)[0].replace(r"[^A-Za-z\ \n]+", " ")
    jql = 'project = OPSDBE_COREMAP AND issuetype = \"Operations Support Request\" AND status = Closed AND text ~ \"{}\" order by created'.format(jql_text)
    issue_id = sendRequest(issue_dict, board, board+api, jql)
    send_jira_mail(board+'browse/'+issue_id, 'I_GLOBAL_DBE_MANAGERS@here.com')
    return issue_id

def env_issue(body, message):
    board = "https://intake.in.here.com/"
    api = "rest/api/2/issue/"
    name ="COREMAPTO"
    summary = convertNone(body['productFormat']) + ' failure for ' + convertNone(body['workspaceName'])
    details = []
    details.append("Region: " + convertNone(body['regionCode','Unknown']))
    details.append("Map Core Version: " + convertNone(body['mapcoreVersion']))
    details.append("MTF version: " + convertNone(body['mtfVersion']))
    details.append('We believe looking at the failure Reason that re-run should resolve the issue. \nAdditional Information for reference:')
    details.append("Failure Message:\n" + message)
    description = '\n'.join(details)

    issue_dict = {
        'fields':{
            'project': {'key': name},
            'issuetype': {'name': 'Task'},
            'customfield_17501':{'id': '21571'},
            'components': [{'name':'Extractions'}],
            'summary': summary,
            'description': description
        }
    }
    jql_text = message.split('\n', 1)[0].replace(r"[^A-Za-z\ \n]+", " ")
    jql = 'project = COREMAPTO AND issuetype = Task AND status = Closed AND text ~ \"{}\" order by created'.format(jql_text)
    issue_id = sendRequest(issue_dict, board, board+api, jql)
    send_jira_mail(board+'browse/'+issue_id, 'I_EU_GRP_OPERATIONS@here.com')
    return issue_id

def app_issue(body, message, err_type):
    board = "https://jiraweb.in.here.com/"
    api = "rest/api/2/issue"
    name ="CMSS"
    summary = 'Auto Jira created for Failure - ' + err_type
    # summary = convertNone(body['productFormat']) + ' failure for ' + convertNone(body['workspaceName'])
    # mtfVersion = convertNone(body['mtfVersion'])
    # if mtfVersion != 'Unknown':
    #     mtfVersion = "REL_MAP_CMSS_" + mtfVersion
    # else:
    #     mtfVersion = 'Version Found_Comments'

    mtfVersion = 'Version Found_Comments'
    details = []
    # details.append("Region: " + convertNone(body['regionCode']))
    # details.append("Map Core Version: " + convertNone(body['mapcoreVersion']))
    details.append("Failure Message:\n" + message)
    details.append("MTF version: " + mtfVersion)
    # details.append("MTF version: " + convertNone(body['mtfVersion']))
    description = '\n'.join(details)

    issue_dict = {
        'fields':{
            'project': {'key': name},
            'issuetype': {'name':'Investigation'},
            'priority': {'id':'1'},
            'components': [{'name':'Map_Extraction'}],
            'labels': [err_type],
            'customfield_10230': {'id':'10032'},
            'customfield_10570': {'name':mtfVersion},
            'summary': summary,
            'description': description
        }
    }
    jql_text = message.split('\n', 1)[0].replace(r"[^A-Za-z\ \n]+", " ")
    print (jql_text)
    jql = 'project = CMSS AND issuetype = Investigation AND status = Done AND text ~ \"{}\" order by created'.format(jql_text)
    issue_id = sendRequest(issue_dict,board, board+api, jql)
    send_jira_mail(board+'browse/'+issue_id, 'CME_PUB_OPAL@here.com', summary)
    return issue_id    

def sendRequest(issue_dict, board, url, jql):
    
    headers={}
    with open('user.json') as f:
        account_details = json.load(f)
    jira_account = account_details.get('jira_username')+':'+account_details.get('jira_password')
    jira_account = base64.b64encode(jira_account.encode('utf-8'))
    headers['Authorization'] = 'Basic '+jira_account.decode('utf-8')
    headers['Content-Type'] = 'application/json'

    jira_suggestions = find_similar_jira(headers, board, jql)
    if len(jira_suggestions) != 0:
        issue_dict['fields']['description'] += '\n\n'+ 50*'='+'\n\nThese already resolved JIRA\'s may be helpful:\n'+jira_suggestions
    response = requests.request('POST', url, headers=headers, data = json.dumps(issue_dict))
    data = json.loads(response.text)
    print(data)
    return data['key']