#!/bin/sh

# start cron
/usr/sbin/cron -f -l 8