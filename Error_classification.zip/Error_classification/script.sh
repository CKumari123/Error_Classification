#!/bin/sh

# code goes here.
echo "Hi run every 2 min"
chmod 777 -R /home
python3 /home/src/errorPredictor.py
python3 /home/src/resolutionPredictor.py